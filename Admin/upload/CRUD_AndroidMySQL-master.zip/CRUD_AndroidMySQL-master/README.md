# CRUD_AndroidMySQL
Membuat Aplikasi CRUD (Create, Read, Update, Delete) di Android Studio berserta dengan web servicesnya menggunakan PHP dan MySQL.

Bahasa yang digunakan pada source code ini adalah:
- Java
- XML
- PHP
- MySQLi



**Ikuti Tutorialnya pada link berikut:** [CRUD Android dengan MySQL](http://www.kodingindonesia.com/belajar-membuat-aplikasi-crud-android-menggunakan-database-mysql/)